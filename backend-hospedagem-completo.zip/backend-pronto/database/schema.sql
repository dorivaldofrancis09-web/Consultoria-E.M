-- Banco de Dados: emm_consultoria
-- Sistema de Agendamentos

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS emm_consultoria CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE emm_consultoria;

-- Tabela de Agendamentos
CREATE TABLE IF NOT EXISTS agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(50) NOT NULL,
    servico VARCHAR(100) NOT NULL,
    data DATE NOT NULL,
    hora TIME NOT NULL,
    mensagem TEXT,
    status ENUM('pendente', 'confirmado', 'cancelado', 'concluido') DEFAULT 'pendente',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_data (data),
    INDEX idx_status (status),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Administradores (opcional para login no painel)
CREATE TABLE IF NOT EXISTS administradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserir administrador padrão (senha: admin123)
-- IMPORTANTE: Altere esta senha após o primeiro login!
INSERT INTO administradores (username, password, email) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'geralemmconsultoria@gmail.com');

-- Tabela de Configurações
CREATE TABLE IF NOT EXISTS configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT,
    descricao TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Configurações iniciais
INSERT INTO configuracoes (chave, valor, descricao) VALUES
('email_notificacao', 'geralemmconsultoria@gmail.com', 'Email para receber notificações de agendamentos'),
('telefone_notificacao', '+244934860617', 'Telefone para receber SMS de notificações'),
('horario_abertura', '08:00', 'Horário de abertura'),
('horario_fechamento', '19:00', 'Horário de fechamento'),
('dias_funcionamento', 'segunda,terça,quarta,quinta,sexta,sábado', 'Dias de funcionamento');
