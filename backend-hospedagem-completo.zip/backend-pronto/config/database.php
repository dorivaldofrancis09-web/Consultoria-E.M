<?php
/**
 * Configuração do Banco de Dados
 * EMM Consultoria - Sistema de Agendamentos
 * 
 * INSTRUÇÕES PARA HOSPEDAGEM:
 * 1. Altere as credenciais abaixo com os dados fornecidos pela sua hospedagem
 * 2. Crie o banco de dados no painel de controle (cPanel/Plesk)
 * 3. Importe o arquivo database/schema.sql
 */

class Database {
    // ========================================
    // CONFIGURAÇÕES - ALTERE AQUI
    // ========================================
    
    // Para LOCALHOST (desenvolvimento)
    private $host = "localhost";
    private $db_name = "emm_consultoria";
    private $username = "root";
    private $password = "";
    
    // Para HOSPEDAGEM (produção)
    // Descomente as linhas abaixo e preencha com os dados da sua hospedagem:
    /*
    private $host = "seuservidor.mysql.database.azure.com";  // Ex: mysql.hostinger.com
    private $db_name = "seu_banco_de_dados";                 // Nome do banco criado
    private $username = "seu_usuario";                        // Usuário do banco
    private $password = "sua_senha_segura";                   // Senha do banco
    */
    
    // ========================================
    // CONEXÃO - NÃO ALTERE
    // ========================================
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                )
            );
        } catch(PDOException $exception) {
            // Em produção, registre o erro em vez de exibí-lo
            error_log("Erro na conexão com o banco: " . $exception->getMessage());
            die(json_encode([
                'success' => false,
                'message' => 'Erro ao conectar com o banco de dados. Contate o suporte.'
            ]));
        }

        return $this->conn;
    }
    
    // Método para testar conexão
    public function testarConexao() {
        try {
            $conn = $this->getConnection();
            if ($conn) {
                return [
                    'success' => true,
                    'message' => 'Conexão estabelecida com sucesso!',
                    'host' => $this->host,
                    'database' => $this->db_name
                ];
            }
        } catch(Exception $e) {
            return [
                'success' => false,
                'message' => 'Erro: ' . $e->getMessage()
            ];
        }
    }
}
?>
