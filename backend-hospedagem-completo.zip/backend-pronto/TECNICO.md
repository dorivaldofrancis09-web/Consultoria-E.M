# 🔧 INFORMAÇÕES TÉCNICAS
## Sistema de Agendamentos E.M.M Consultoria

---

## 📊 ESPECIFICAÇÕES DO SISTEMA

### Versão
- **Versão:** 1.0.0
- **Data de Release:** Janeiro 2026
- **Status:** Produção

### Tecnologias

**Backend:**
- PHP 8.0+ (compatível com 7.4+)
- MySQL 5.7+ / MariaDB 10.2+
- PDO (PHP Data Objects)
- JSON para comunicação API

**Frontend:**
- HTML5
- CSS3 (Grid/Flexbox)
- JavaScript ES6+ (Vanilla)
- Fetch API

**Servidor:**
- Apache 2.4+
- mod_rewrite (para URLs amigáveis)
- mod_headers (para CORS)
- mod_deflate (para compressão)

---

## 🗄️ ESTRUTURA DO BANCO DE DADOS

### Tabela: `agendamentos`
```sql
CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(50) NOT NULL,
    servico VARCHAR(100) NOT NULL,
    data DATE NOT NULL,
    hora TIME NOT NULL,
    mensagem TEXT,
    status ENUM('pendente', 'confirmado', 'cancelado', 'concluido') DEFAULT 'pendente',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_data (data),
    INDEX idx_status (status),
    INDEX idx_email (email)
);
```

**Campos:**
- `id`: Identificador único
- `nome`: Nome completo do cliente
- `email`: Email do cliente
- `telefone`: Telefone com código do país
- `servico`: Tipo de serviço solicitado
- `data`: Data do agendamento (YYYY-MM-DD)
- `hora`: Hora do agendamento (HH:MM:SS)
- `mensagem`: Mensagem adicional (opcional)
- `status`: Estado do agendamento
- `created_at`: Data de criação
- `updated_at`: Data da última atualização

**Índices:**
- `idx_data`: Otimiza buscas por data
- `idx_status`: Otimiza filtros por status
- `idx_email`: Otimiza buscas por cliente

---

### Tabela: `administradores`
```sql
CREATE TABLE administradores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Credenciais Padrão:**
- Usuário: `admin`
- Senha: `admin123` (hash: bcrypt)
- **⚠️ ALTERE APÓS PRIMEIRO LOGIN!**

---

### Tabela: `configuracoes`
```sql
CREATE TABLE configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT,
    descricao TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

**Configurações Padrão:**
- `email_notificacao`: geralemmconsultoria@gmail.com
- `telefone_notificacao`: +244934860617
- `horario_abertura`: 08:00
- `horario_fechamento`: 19:00
- `dias_funcionamento`: segunda,terça,quarta,quinta,sexta,sábado

---

## 🔌 ENDPOINTS DA API

### Base URL
```
https://seudominio.com/api/
```

---

### 1. Criar Agendamento
**Endpoint:** `POST /api/criar-agendamento.php`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "nome": "João Silva",
  "email": "joao@example.com",
  "telefone": "+244999999999",
  "servico": "Consultoria Fiscal",
  "data": "2026-02-15",
  "hora": "10:00",
  "mensagem": "Mensagem opcional"
}
```

**Resposta (Sucesso - 201):**
```json
{
  "success": true,
  "message": "Agendamento criado com sucesso!",
  "id": 123
}
```

**Resposta (Erro - 400):**
```json
{
  "success": false,
  "message": "Horário já agendado"
}
```

**Validações:**
- Nome: obrigatório, mín 3 caracteres
- Email: obrigatório, formato válido
- Telefone: obrigatório
- Data: obrigatório, não pode ser passada
- Hora: obrigatório, entre 08:00-19:00
- Horário não pode estar ocupado

---

### 2. Listar Agendamentos
**Endpoint:** `GET /api/listar-agendamentos.php`

**Parâmetros (Query):**
- `status` (opcional): pendente|confirmado|cancelado|concluido
- `data` (opcional): YYYY-MM-DD
- `page` (opcional): número da página (padrão: 1)
- `limit` (opcional): itens por página (padrão: 10)

**Exemplos:**
```
/api/listar-agendamentos.php
/api/listar-agendamentos.php?status=pendente
/api/listar-agendamentos.php?data=2026-02-15
/api/listar-agendamentos.php?page=2&limit=20
```

**Resposta (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "nome": "João Silva",
      "email": "joao@example.com",
      "telefone": "+244999999999",
      "servico": "Consultoria Fiscal",
      "data": "2026-02-15",
      "hora": "10:00:00",
      "mensagem": "...",
      "status": "pendente",
      "created_at": "2026-02-10 14:30:00",
      "updated_at": "2026-02-10 14:30:00"
    }
  ],
  "total": 1,
  "page": 1,
  "limit": 10
}
```

---

### 3. Atualizar Status
**Endpoint:** `POST /api/atualizar-status.php`

**Headers:**
```
Content-Type: application/json
```

**Body:**
```json
{
  "id": 123,
  "status": "confirmado"
}
```

**Status válidos:**
- `pendente`
- `confirmado`
- `cancelado`
- `concluido`

**Resposta (Sucesso - 200):**
```json
{
  "success": true,
  "message": "Status atualizado com sucesso!"
}
```

**Resposta (Erro - 404):**
```json
{
  "success": false,
  "message": "Agendamento não encontrado"
}
```

---

## 🔐 SEGURANÇA

### Implementações de Segurança

1. **SQL Injection:**
   - PDO com prepared statements
   - Binding de parâmetros

2. **XSS (Cross-Site Scripting):**
   - Sanitização de inputs
   - htmlspecialchars() em outputs

3. **CORS:**
   - Headers configurados no .htaccess
   - Permite requisições cross-origin

4. **Validação de Dados:**
   - Backend: validação completa
   - Frontend: validação preliminar

5. **Senhas:**
   - Hash bcrypt (custo 10)
   - Nunca armazenadas em texto plano

6. **Arquivos Sensíveis:**
   - .htaccess protege database.php
   - .htaccess protege schema.sql
   - Diretórios não listáveis

---

## ⚙️ CONFIGURAÇÕES DO APACHE

### .htaccess
```apache
# Desabilitar listagem
Options -Indexes

# Proteger arquivos
<Files "database.php">
    Order allow,deny
    Deny from all
</Files>

# Força HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Compressão GZIP
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript
</IfModule>

# Cache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>

# CORS
<IfModule mod_headers.c>
    Header set Access-Control-Allow-Origin "*"
    Header set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
</IfModule>
```

---

## 📦 REQUISITOS DE HOSPEDAGEM

### Mínimos:
- **PHP:** 7.4 ou superior
- **MySQL:** 5.7 ou superior
- **Espaço:** 100 MB
- **Memória:** 128 MB
- **Extensões PHP:**
  - PDO
  - pdo_mysql
  - json
  - mbstring

### Recomendados:
- **PHP:** 8.0+
- **MySQL:** 8.0+
- **Espaço:** 500 MB
- **Memória:** 256 MB
- **SSL:** Certificado Let's Encrypt
- **Backup:** Diário automático

---

## 🚀 OTIMIZAÇÕES

### Performance

1. **Banco de Dados:**
   - Índices nas colunas mais consultadas
   - Consultas otimizadas
   - Conexão persistente (PDO)

2. **Frontend:**
   - Minificação CSS/JS (opcional)
   - Lazy loading de imagens
   - Cache de assets

3. **Servidor:**
   - Compressão GZIP ativada
   - Cache de headers
   - KeepAlive habilitado

### Escalabilidade

Para crescimento futuro:
- Separar banco em servidor dedicado
- Usar CDN para assets estáticos
- Implementar cache Redis/Memcached
- Load balancer para múltiplos servidores

---

## 📊 MÉTRICAS E LIMITES

### Capacidade Atual:
- **Agendamentos simultâneos:** Ilimitado (depende do banco)
- **Requisições/segundo:** ~100 (servidor básico)
- **Tamanho máximo POST:** 20 MB
- **Timeout PHP:** 300 segundos

### Limites Recomendados:
- **Agendamentos por dia:** 100-200
- **Agendamentos por horário:** 1 (configurável)
- **Horário de funcionamento:** 08:00-19:00 (configurável)

---

## 🔄 BACKUP E RECUPERAÇÃO

### Backup Manual:

**Banco de Dados:**
```bash
mysqldump -u usuario -p emm_consultoria > backup.sql
```

**Arquivos:**
```bash
tar -czf backup-arquivos.tar.gz /caminho/para/public_html/
```

### Restauração:

**Banco de Dados:**
```bash
mysql -u usuario -p emm_consultoria < backup.sql
```

**Arquivos:**
```bash
tar -xzf backup-arquivos.tar.gz -C /caminho/destino/
```

---

## 🐛 DEBUG MODE

### Ativar (Apenas em Desenvolvimento):

No topo de cada arquivo PHP:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

### Desativar (Produção):

No topo de cada arquivo PHP:
```php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/caminho/para/logs/php-errors.log');
```

---

## 📞 SUPORTE TÉCNICO

Para questões técnicas específicas:

📧 **Email:** geralemmconsultoria@gmail.com  
📱 **WhatsApp:** +244 934 860 617  

**Horário:** Segunda a Sexta, 08:00-19:00 (Luanda)

---

**Desenvolvido com ❤️ para E.M.M Consultoria**  
**Versão:** 1.0.0 | **Data:** Janeiro 2026
