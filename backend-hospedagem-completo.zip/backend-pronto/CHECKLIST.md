# ✅ CHECKLIST DE INSTALAÇÃO
## Sistema de Agendamentos E.M.M Consultoria

Use este checklist para garantir que nada foi esquecido durante a instalação.

---

## 📋 ANTES DE COMEÇAR

- [ ] Hospedagem contratada
- [ ] Domínio registrado (ou subdomínio criado)
- [ ] Acesso ao painel de controle (cPanel/hPanel)
- [ ] Dados de acesso FTP em mãos
- [ ] Backup de todos os arquivos locais

---

## 🗄️ BANCO DE DADOS

### Criação
- [ ] Banco MySQL criado
- [ ] Nome do banco: `emm_consultoria` (ou outro escolhido)
- [ ] Usuário MySQL criado
- [ ] Senha forte definida
- [ ] Privilégios concedidos ao usuário (ALL PRIVILEGES)
- [ ] Credenciais anotadas em local seguro

### Importação
- [ ] phpMyAdmin acessado
- [ ] Banco selecionado
- [ ] Arquivo `schema.sql` importado
- [ ] Importação sem erros
- [ ] Tabelas criadas:
  - [ ] `agendamentos`
  - [ ] `administradores`
  - [ ] `configuracoes`

---

## 📤 UPLOAD DE ARQUIVOS

### Via FTP
- [ ] FileZilla (ou similar) instalado
- [ ] Conexão FTP estabelecida
- [ ] Navegado até `/public_html/`
- [ ] Todos os arquivos enviados
- [ ] Estrutura de pastas verificada:
  - [ ] `/api/`
  - [ ] `/config/`
  - [ ] `/database/`
  - [ ] `/admin/`
  - [ ] `/frontend/` (se houver)

### Ou Via File Manager
- [ ] Gerenciador de arquivos acessado
- [ ] Pasta `/public_html/` aberta
- [ ] Arquivos enviados via upload
- [ ] Upload 100% concluído

---

## ⚙️ CONFIGURAÇÃO

### 1. Arquivo database.php
- [ ] Arquivo `config/database.php` aberto para edição
- [ ] Linha do `$host` atualizada (se necessário)
- [ ] Linha do `$db_name` atualizada
- [ ] Linha do `$username` atualizada
- [ ] Linha do `$password` atualizada
- [ ] Arquivo salvo

**Exemplo:**
```php
private $host = "localhost";
private $db_name = "emm_consultoria";
private $username = "emm_user";
private $password = "MinHaSeNh@Forte123";
```

### 2. Permissões (se necessário)
- [ ] Pastas: 755
- [ ] Arquivos PHP: 644
- [ ] `.htaccess`: 644

### 3. SSL/HTTPS
- [ ] Certificado SSL ativado na hospedagem
- [ ] Let's Encrypt configurado (se disponível)
- [ ] Linhas do `.htaccess` descomentadas para forçar HTTPS
- [ ] Site acessível via `https://`

---

## 🧪 TESTES

### 1. Teste de Conexão
- [ ] Acessado: `https://seudominio.com/testar-conexao.php`
- [ ] Resultado: `"success": true`
- [ ] Tabelas listadas corretamente
- [ ] Arquivo `testar-conexao.php` **DELETADO**

### 2. Teste da API
- [ ] Endpoint testado: `/api/listar-agendamentos.php`
- [ ] Retornou JSON válido
- [ ] Sem erros 404 ou 500
- [ ] CORS funcionando (sem erros no console)

### 3. Teste do Frontend
- [ ] Painel admin carregou: `/admin/index.html`
- [ ] Dashboard exibe corretamente
- [ ] Estatísticas aparecem (mesmo que zeradas)
- [ ] Sem erros no console (F12)

### 4. Teste Completo
- [ ] Formulário de agendamento acessado
- [ ] Dados preenchidos
- [ ] Formulário enviado
- [ ] Mensagem de sucesso exibida
- [ ] Agendamento aparece no painel admin
- [ ] Status está como "Pendente"
- [ ] Dados corretos salvos

---

## 🔔 NOTIFICAÇÕES (Opcional)

### Email
- [ ] SMTP configurado na hospedagem
- [ ] Email de teste enviado
- [ ] Email recebido corretamente
- [ ] Formatação do email OK

---

## 🔐 SEGURANÇA

- [ ] Arquivo `testar-conexao.php` DELETADO
- [ ] Senha do banco de dados FORTE
- [ ] Arquivo `.env.example` NÃO contém senha real
- [ ] Backup inicial criado
- [ ] `.htaccess` configurado corretamente
- [ ] Listagem de diretórios desabilitada

---

## 🎨 PERSONALIZAÇÃO (Opcional)

### URLs
- [ ] URL da API atualizada no frontend
- [ ] URLs absolutas verificadas
- [ ] Links internos funcionando

### Branding
- [ ] Logo da empresa adicionado (se houver)
- [ ] Cores personalizadas (se desejar)
- [ ] Textos ajustados

### Configurações
- [ ] Horários de funcionamento verificados
- [ ] Serviços listados corretamente
- [ ] Email de notificação atualizado
- [ ] Telefone atualizado

---

## 📊 PÓS-INSTALAÇÃO

### Documentação
- [ ] Credenciais salvas em local seguro
- [ ] Documentação lida
- [ ] Guias salvos para referência

### Backup
- [ ] Backup do banco de dados criado
- [ ] Backup dos arquivos criado
- [ ] Localização dos backups anotada

### Monitoramento
- [ ] Uptime monitor configurado (opcional)
- [ ] Google Analytics adicionado (opcional)
- [ ] Email de notificação testado

---

## ✅ FINALIZAÇÃO

- [ ] Todos os itens acima verificados
- [ ] Sistema funcionando 100%
- [ ] Usuários podem agendar
- [ ] Admin consegue gerenciar
- [ ] Não há erros visíveis
- [ ] Performance satisfatória
- [ ] Mobile responsivo

---

## 🎉 PRONTO!

**Se todos os itens estão marcados, seu sistema está ONLINE e FUNCIONANDO!**

**Acessos:**
- 🌐 Site Público: `https://seudominio.com/frontend/`
- 🔐 Painel Admin: `https://seudominio.com/admin/`

---

## 📞 SUPORTE

Se algum item não foi concluído ou há erros:

1. Verifique o `GUIA-HOSPEDAGEM.md` - Seção "Solução de Problemas"
2. Revise este checklist do início
3. Entre em contato:

📧 **Email:** geralemmconsultoria@gmail.com  
📱 **WhatsApp:** +244 934 860 617

---

**Desenvolvido com ❤️ para E.M.M Consultoria**  
**Versão:** 1.0.0 | **Data:** Janeiro 2026
