# 🚀 BACKEND PRONTO PARA HOSPEDAGEM
## Sistema de Agendamentos E.M.M Consultoria

---

## ✅ O QUE TEM NESTE PACOTE?

Este pacote contém **TUDO** que você precisa para colocar o sistema no ar:

```
📦 backend-pronto/
├── 📁 api/                          # Endpoints da API
│   ├── criar-agendamento.php        # Criar novos agendamentos
│   ├── listar-agendamentos.php      # Listar todos agendamentos
│   └── atualizar-status.php         # Atualizar status
│
├── 📁 config/                       # Configurações
│   └── database.php                 # Conexão com banco de dados
│
├── 📁 database/                     # Scripts SQL
│   └── schema.sql                   # Criar tabelas no banco
│
├── 📁 admin/                        # Painel Administrativo
│   ├── index.html                   # Dashboard
│   └── test.html                    # Testes
│
├── 📄 .htaccess                     # Configurações Apache
├── 📄 .env.example                  # Exemplo de variáveis de ambiente
├── 📄 testar-conexao.php           # Script para testar banco
├── 📄 GUIA-HOSPEDAGEM.md           # Guia completo passo a passo
└── 📄 README.md                     # Este arquivo
```

---

## 🎯 PRÓXIMOS PASSOS

### 1️⃣ LEIA O GUIA
📖 **Abra:** `GUIA-HOSPEDAGEM.md`

Este guia contém:
- ✅ Como escolher hospedagem
- ✅ Passo a passo COMPLETO da Hostinger
- ✅ Passo a passo COMPLETO da HostGator
- ✅ Como criar banco de dados
- ✅ Como fazer upload via FTP
- ✅ Como configurar tudo
- ✅ Solução de problemas

### 2️⃣ ESCOLHA SUA HOSPEDAGEM
Recomendações:
- **Hostinger** - Melhor custo-benefício (~$2-4/mês)
- **HostGator** - Boa opção para Angola
- **SiteGround** - Melhor performance

### 3️⃣ SIGA O PASSO A PASSO
O guia tem instruções DETALHADAS com prints e exemplos.

---

## ⚡ RESUMO RÁPIDO (SE VOCÊ JÁ CONHECE)

### 1. Criar Banco de Dados
```sql
-- No phpMyAdmin da sua hospedagem
CREATE DATABASE emm_consultoria;
```

### 2. Importar Schema
- Importar arquivo: `database/schema.sql`

### 3. Configurar Conexão
Editar `config/database.php`:
```php
private $host = "localhost";
private $db_name = "emm_consultoria";  // Seu banco
private $username = "seu_usuario";      // Seu usuário
private $password = "sua_senha";        // Sua senha
```

### 4. Upload via FTP
- Enviar TODOS os arquivos para `/public_html/`

### 5. Testar
- Acessar: `https://seudominio.com/testar-conexao.php`
- Se der sucesso, **DELETE** este arquivo!

### 6. Pronto! 🎉
- Site: `https://seudominio.com/frontend/index.html`
- Admin: `https://seudominio.com/admin/index.html`

---

## 🔧 REQUISITOS DA HOSPEDAGEM

Certifique-se que sua hospedagem tem:

✅ PHP 7.4+ (recomendado PHP 8.0+)  
✅ MySQL 5.7+ ou MariaDB 10.2+  
✅ Suporte a PDO (PHP Data Objects)  
✅ Pelo menos 100 MB de espaço  
✅ SSL/HTTPS habilitado  
✅ Acesso FTP ou File Manager  

---

## 📋 CHECKLIST DE INSTALAÇÃO

Marque conforme for fazendo:

- [ ] Hospedagem contratada
- [ ] Domínio registrado ou apontado
- [ ] Banco de dados criado
- [ ] Schema importado (tabelas criadas)
- [ ] `database.php` configurado
- [ ] Arquivos enviados via FTP
- [ ] Teste de conexão passou
- [ ] API funcionando
- [ ] Painel admin carregando
- [ ] Formulário criando agendamentos
- [ ] SSL ativado (HTTPS)
- [ ] `testar-conexao.php` DELETADO

---

## 🐛 PROBLEMAS COMUNS

### ❌ Erro de conexão com banco
➡️ Verifique `config/database.php`  
➡️ Confirme usuário e senha no painel da hospedagem

### ❌ 500 Internal Server Error
➡️ Verifique versão do PHP (precisa ser 7.4+)  
➡️ Ative exibição de erros para ver detalhes

### ❌ API não responde (404)
➡️ Confirme que arquivos estão em `/public_html/api/`  
➡️ Verifique `.htaccess`

### ❌ CORS Error
➡️ Headers CORS já estão nos arquivos  
➡️ Se persistir, verifique configuração do Apache

📖 **Mais soluções:** Veja `GUIA-HOSPEDAGEM.md`

---

## 📞 SUPORTE

**E.M.M Consultoria**  
📧 Email: geralemmconsultoria@gmail.com  
📱 WhatsApp: +244 934 860 617  

---

## 🎓 DICAS IMPORTANTES

### 💡 Segurança
1. **SEMPRE** use senhas fortes para o banco
2. **DELETE** o arquivo `testar-conexao.php` após usar
3. Ative SSL/HTTPS
4. Faça backup regular do banco

### 💡 Performance
1. Use cache se a hospedagem oferecer
2. Otimize imagens do frontend
3. Ative compressão GZIP

### 💡 Manutenção
1. Faça backup semanal
2. Monitore espaço em disco
3. Acompanhe logs de erro

---

## 📊 RECURSOS DO SISTEMA

### ✨ Para Clientes (Frontend)
- Formulário de agendamento online
- Seleção de data e hora
- Validação automática de horários
- Email de confirmação

### 🎯 Para Você (Painel Admin)
- Dashboard com estatísticas
- Lista de todos os agendamentos
- Filtros por status e data
- Confirmar/Cancelar agendamentos
- Visualizar detalhes completos

### 🔔 Notificações
- Email automático para cliente
- Email de alerta para você
- Notificação de novos agendamentos

---

## 🌐 TECNOLOGIAS

**Backend:**
- PHP 8.0+ com PDO
- MySQL 5.7+
- API RESTful
- CORS habilitado

**Frontend:**
- HTML5 + CSS3
- JavaScript Vanilla
- Design responsivo
- Fetch API

---

## 📈 PRÓXIMAS MELHORIAS (Opcional)

- [ ] Sistema de login para admin
- [ ] Calendário visual
- [ ] Exportar relatórios PDF
- [ ] Integração Google Calendar
- [ ] Lembretes SMS automáticos
- [ ] App mobile

---

## ⚖️ LICENÇA

Sistema desenvolvido exclusivamente para **E.M.M Consultoria**.

---

## 🙏 AGRADECIMENTOS

Sistema desenvolvido para facilitar a gestão de agendamentos e proporcionar melhor experiência aos clientes da E.M.M Consultoria.

---

**Versão:** 1.0.0  
**Data:** Janeiro 2026  
**Status:** ✅ Pronto para produção

---

**🚀 Boa sorte com a hospedagem!**

Se tiver qualquer dúvida, não hesite em entrar em contato.

---

**Desenvolvido com ❤️ para E.M.M Consultoria**
