# ⚡ INÍCIO RÁPIDO - 5 MINUTOS
## Sistema de Agendamentos E.M.M Consultoria

**Se você tem pressa, siga estes passos:**

---

## 🚀 EM 5 PASSOS

### 1️⃣ HOSPEDAGEM (2 min)
1. Contrate: [Hostinger](https://hostinger.com) ou [HostGator](https://hostgator.com)
2. Anote: domínio, usuário e senha

### 2️⃣ BANCO DE DADOS (1 min)
1. Painel > **MySQL Databases**
2. Criar banco: `emm_consultoria`
3. Criar usuário com senha forte
4. Anote as credenciais!

### 3️⃣ IMPORTAR TABELAS (30 seg)
1. Painel > **phpMyAdmin**
2. Selecionar banco `emm_consultoria`
3. Importar > `database/schema.sql`
4. Executar ✅

### 4️⃣ CONFIGURAR (1 min)
Edite `config/database.php`:
```php
private $host = "localhost";
private $db_name = "emm_consultoria";     // ← Seu banco
private $username = "seu_usuario";         // ← Seu usuário
private $password = "sua_senha";           // ← Sua senha
```

### 5️⃣ UPLOAD (30 seg)
1. Painel > **File Manager**
2. Ir para `/public_html/`
3. Upload de **TODOS** os arquivos
4. Aguardar conclusão

---

## ✅ TESTAR

**Acesse:**
```
https://seudominio.com/testar-conexao.php
```

**Se aparecer** `"success": true` → **FUNCIONOU!** 🎉

**DELETE** o arquivo `testar-conexao.php` agora.

---

## 🌐 ACESSAR

**Site Público:**
```
https://seudominio.com/frontend/index.html
```

**Painel Admin:**
```
https://seudominio.com/admin/index.html
```

---

## ❌ DEU ERRO?

**Erro de conexão:**
→ Revise `config/database.php`
→ Verifique usuário/senha

**500 Error:**
→ Verifique versão do PHP (precisa 7.4+)

**404 Not Found:**
→ Confirme estrutura de pastas
→ Arquivos em `/public_html/`

---

## 📚 PRECISA DE MAIS DETALHES?

Leia os guias completos:
- 📖 `GUIA-HOSPEDAGEM.md` - Passo a passo detalhado
- ✅ `CHECKLIST.md` - Lista completa de verificação
- 📄 `README.md` - Informações gerais

---

## 📞 AJUDA

📧 geralemmconsultoria@gmail.com  
📱 +244 934 860 617

---

**Pronto! Seu sistema está no ar! 🚀**
