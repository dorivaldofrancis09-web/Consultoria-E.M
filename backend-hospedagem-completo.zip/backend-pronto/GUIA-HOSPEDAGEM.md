# 🚀 GUIA COMPLETO DE HOSPEDAGEM
## Sistema de Agendamentos E.M.M Consultoria

---

## 📋 ÍNDICE
1. [Requisitos Mínimos](#requisitos-mínimos)
2. [Escolhendo Hospedagem](#escolhendo-hospedagem)
3. [Passo a Passo - Hostinger](#passo-a-passo---hostinger)
4. [Passo a Passo - HostGator](#passo-a-passo---hostgator)
5. [Configuração do Banco de Dados](#configuração-do-banco-de-dados)
6. [Upload dos Arquivos](#upload-dos-arquivos)
7. [Configuração Final](#configuração-final)
8. [Testes](#testes)
9. [Solução de Problemas](#solução-de-problemas)

---

## 💻 REQUISITOS MÍNIMOS

Sua hospedagem precisa ter:

✅ **PHP 7.4 ou superior** (recomendado PHP 8.0+)  
✅ **MySQL 5.7 ou superior** (ou MariaDB 10.2+)  
✅ **Suporte a PDO** (PHP Data Objects)  
✅ **Pelo menos 100 MB de espaço em disco**  
✅ **Certificado SSL** (https://)  
✅ **Acesso FTP ou Gerenciador de Arquivos**  

---

## 🏢 ESCOLHENDO HOSPEDAGEM

### Opções Recomendadas para Angola:

#### 1. **Hostinger** ⭐ MELHOR CUSTO-BENEFÍCIO
- **Preço:** ~$2-4 USD/mês
- **PHP:** 8.2 ✅
- **MySQL:** Ilimitado ✅
- **SSL Grátis:** Sim ✅
- **Suporte:** 24/7
- **Link:** https://www.hostinger.com

#### 2. **HostGator**
- **Preço:** ~$3-6 USD/mês
- **PHP:** 8.1 ✅
- **MySQL:** Ilimitado ✅
- **SSL Grátis:** Sim ✅
- **Link:** https://www.hostgator.com

#### 3. **SiteGround**
- **Preço:** ~$4-8 USD/mês
- **PHP:** 8.2 ✅
- **Performance:** Excelente ✅
- **Link:** https://www.siteground.com

#### 4. **Locaweb** (Brasil, mas aceita clientes de Angola)
- **Preço:** ~R$ 15-30/mês
- **Suporte em Português:** Sim ✅
- **Link:** https://www.locaweb.com.br

---

## 🌟 PASSO A PASSO - HOSTINGER

### PASSO 1: Criar Conta e Contratar Plano

1. Acesse: https://www.hostinger.com
2. Escolha o plano **Premium** ou **Business**
3. Registre seu domínio ou use um existente
4. Complete o pagamento

### PASSO 2: Acessar o Painel (hPanel)

1. Faça login em: https://hpanel.hostinger.com
2. Clique em **Websites**
3. Selecione seu domínio

### PASSO 3: Criar Banco de Dados MySQL

1. No painel lateral, clique em **Banco de Dados MySQL**
2. Clique em **Criar Novo Banco de Dados**
3. Preencha:
   - **Nome do Banco:** `emm_consultoria`
   - **Usuário:** `emm_user` (ou outro de sua escolha)
   - **Senha:** Crie uma senha forte
4. **ANOTE ESTES DADOS!** Você vai precisar deles.

### PASSO 4: Importar o Schema

1. Ainda na página de Banco de Dados, clique em **Gerenciar** (phpMyAdmin)
2. No phpMyAdmin:
   - Clique no banco `emm_consultoria` no menu lateral
   - Clique na aba **Importar**
   - Clique em **Escolher arquivo**
   - Selecione o arquivo `database/schema.sql`
   - Clique em **Executar**
3. ✅ Tabelas criadas com sucesso!

### PASSO 5: Upload dos Arquivos via FTP

#### Opção A: Usando FileZilla (Recomendado)

1. **Baixe o FileZilla:** https://filezilla-project.org/
2. **Conecte-se:**
   - Host: `ftp.seudominio.com` (ver no painel Hostinger)
   - Usuário: Seu usuário FTP
   - Senha: Sua senha FTP
   - Porta: 21
3. **Navegue até:** `/public_html/`
4. **Faça upload de TODOS os arquivos** desta pasta

#### Opção B: Usando Gerenciador de Arquivos (Mais Fácil)

1. No hPanel, clique em **Gerenciador de Arquivos**
2. Navegue até `/public_html/`
3. Clique em **Upload**
4. Selecione TODOS os arquivos desta pasta
5. Aguarde o upload concluir

### PASSO 6: Configurar o Banco de Dados

1. **Edite o arquivo:** `config/database.php`
2. **Localize as linhas:**
   ```php
   private $host = "localhost";
   private $db_name = "emm_consultoria";
   private $username = "root";
   private $password = "";
   ```
3. **Altere para:**
   ```php
   private $host = "localhost";  // Mantenha como localhost
   private $db_name = "emm_consultoria";  // Nome do banco que você criou
   private $username = "emm_user";  // Usuário que você criou
   private $password = "sua_senha_forte";  // Senha que você definiu
   ```
4. **Salve o arquivo**

### PASSO 7: Testar a Conexão

1. Acesse: `https://seudominio.com/testar-conexao.php`
2. Se aparecer: `"success": true` ✅ Tudo certo!
3. **DELETE o arquivo** `testar-conexao.php` por segurança

### PASSO 8: Configurar URLs no Frontend

1. **Edite:** `admin/index.html`
2. **Localize:** (linhas ~22-24)
   ```javascript
   const API_URL = 'http://localhost/backend/api';
   ```
3. **Altere para:**
   ```javascript
   const API_URL = 'https://seudominio.com/api';
   ```
4. **Salve o arquivo**

### PASSO 9: Acessar o Sistema

🌐 **Site Público:** https://seudominio.com/frontend/index.html  
🔐 **Painel Admin:** https://seudominio.com/admin/index.html

---

## 🔧 PASSO A PASSO - HOSTGATOR

### PASSO 1: Contratar Hospedagem

1. Acesse: https://www.hostgator.com
2. Escolha plano **Hatchling** ou **Baby**
3. Complete o cadastro e pagamento

### PASSO 2: Acessar cPanel

1. Acesse: `https://seudominio.com:2083`
2. Ou pelo painel do cliente: **Meus Produtos > Web Hosting > Gerenciar**

### PASSO 3: Criar Banco MySQL

1. No cPanel, procure por **MySQL® Databases**
2. Em **Create New Database:**
   - Nome: `emm_consultoria`
   - Clique em **Create Database**
3. Em **Add New User:**
   - Username: `emm_user`
   - Password: Crie senha forte
   - Clique em **Create User**
4. Em **Add User to Database:**
   - Selecione o usuário `emm_user`
   - Selecione o banco `emm_consultoria`
   - Marque **ALL PRIVILEGES**
   - Clique em **Make Changes**

### PASSO 4: Importar Schema

1. No cPanel, clique em **phpMyAdmin**
2. Selecione o banco `emm_consultoria`
3. Clique em **Import**
4. Escolha `database/schema.sql`
5. Clique em **Go**

### PASSO 5: Upload via FTP

1. No cPanel, clique em **File Manager**
2. Navegue até `public_html`
3. Clique em **Upload**
4. Selecione todos os arquivos desta pasta
5. Aguarde conclusão

### PASSO 6: Configurar database.php

Mesmo processo da Hostinger (Passo 6)

---

## ⚙️ CONFIGURAÇÃO DO BANCO DE DADOS

### Estrutura das Credenciais:

```php
// LOCALHOST (Desenvolvimento)
private $host = "localhost";
private $db_name = "emm_consultoria";
private $username = "root";
private $password = "";

// PRODUÇÃO (Hospedagem)
private $host = "localhost";  // Quase sempre é localhost
private $db_name = "nome_do_banco";  // Fornecido pela hospedagem
private $username = "usuario_mysql";  // Fornecido pela hospedagem
private $password = "senha_forte";  // Definida por você
```

### 🔍 Onde encontrar essas informações?

- **Hostinger:** Banco de Dados > Detalhes do Banco
- **HostGator:** cPanel > MySQL Databases
- **Outros:** Procure no painel de controle

---

## 📤 UPLOAD DOS ARQUIVOS

### Estrutura Final no Servidor:

```
public_html/
├── api/
│   ├── criar-agendamento.php
│   ├── listar-agendamentos.php
│   └── atualizar-status.php
├── config/
│   └── database.php
├── database/
│   └── schema.sql
├── admin/
│   └── index.html
├── frontend/
│   └── index.html (se houver)
├── .htaccess
└── testar-conexao.php (deletar após teste)
```

---

## 🔐 CONFIGURAÇÃO FINAL

### 1. Configurar Email (Opcional mas Recomendado)

Para receber notificações de agendamentos:

1. No painel da hospedagem, crie um email: `agendamentos@seudominio.com`
2. Edite `api/criar-agendamento.php`
3. Configure o SMTP (se disponível na hospedagem)

### 2. Configurar SSL (HTTPS)

1. No painel da hospedagem, procure por **SSL/TLS**
2. Ative o **Let's Encrypt SSL** (grátis)
3. Force HTTPS editando `.htaccess`:

```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 3. Configurar Permissões

Via FTP ou File Manager:
- Pastas: 755
- Arquivos PHP: 644
- `.htaccess`: 644

---

## ✅ TESTES

### 1. Teste de Conexão com Banco
```
https://seudominio.com/testar-conexao.php
```
Deve retornar: `"success": true`

### 2. Teste de API - Listar Agendamentos
```
https://seudominio.com/api/listar-agendamentos.php
```
Deve retornar JSON (mesmo que vazio)

### 3. Teste de Frontend
```
https://seudominio.com/admin/index.html
```
Deve carregar o painel administrativo

### 4. Teste de Agendamento Completo

1. Acesse o site público
2. Preencha o formulário
3. Envie
4. Verifique no painel admin se apareceu

---

## 🐛 SOLUÇÃO DE PROBLEMAS

### ❌ Erro: "Conexão com banco falhou"

**Causa:** Credenciais incorretas  
**Solução:**
1. Verifique `config/database.php`
2. Confirme usuário, senha e nome do banco
3. Teste com `testar-conexao.php`

---

### ❌ Erro: "500 Internal Server Error"

**Causa:** Erro no código PHP  
**Solução:**
1. Ative exibição de erros temporariamente
2. Adicione no topo do PHP:
   ```php
   error_reporting(E_ALL);
   ini_set('display_errors', 1);
   ```
3. Veja o erro específico
4. **Desative depois!**

---

### ❌ Erro: "Access denied for user"

**Causa:** Usuário do banco sem permissão  
**Solução:**
1. No phpMyAdmin, verifique privilégios
2. Garanta que tem: SELECT, INSERT, UPDATE, DELETE

---

### ❌ API não responde (404)

**Causa:** URL incorreta  
**Solução:**
1. Verifique se os arquivos estão em `/public_html/api/`
2. Teste acessando diretamente: `seudominio.com/api/listar-agendamentos.php`
3. Verifique `.htaccess`

---

### ❌ CORS Error no navegador

**Causa:** Problema de domínio cruzado  
**Solução:**
1. Adicione no topo de cada arquivo da API:
   ```php
   header('Access-Control-Allow-Origin: *');
   header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
   header('Access-Control-Allow-Headers: Content-Type');
   ```

---

### ❌ Formulário não envia

**Causa:** URL da API incorreta no frontend  
**Solução:**
1. Abra `admin/index.html`
2. Procure por `API_URL`
3. Atualize para: `https://seudominio.com/api`
4. Limpe cache do navegador (Ctrl+F5)

---

## 📊 CHECKLIST FINAL

Antes de considerar concluído, verifique:

- [ ] Banco de dados criado
- [ ] Schema importado (tabelas criadas)
- [ ] Todos os arquivos enviados via FTP
- [ ] `database.php` configurado corretamente
- [ ] Teste de conexão passou
- [ ] API responde (testar listar-agendamentos)
- [ ] Painel admin carrega
- [ ] Consegue criar agendamento
- [ ] SSL ativado (HTTPS)
- [ ] Email de notificação configurado (opcional)
- [ ] Arquivo `testar-conexao.php` DELETADO

---

## 🎉 PRONTO!

Se chegou até aqui, seu sistema está ONLINE! 🚀

**Acessos:**
- Site: `https://seudominio.com/frontend/index.html`
- Admin: `https://seudominio.com/admin/index.html`

---

## 📞 SUPORTE

Se precisar de ajuda:

📧 **Email:** geralemmconsultoria@gmail.com  
📱 **WhatsApp:** +244 934 860 617  

---

**Desenvolvido com ❤️ para E.M.M Consultoria**  
**Versão:** 1.0.0 | **Data:** Janeiro 2026
