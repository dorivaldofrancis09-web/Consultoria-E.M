<?php
/**
 * API: Listar Agendamentos
 * EMM Consultoria
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

// Conectar ao banco
$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro ao conectar com o banco de dados."
    ));
    exit();
}

// Parâmetros opcionais
$status = isset($_GET['status']) ? $_GET['status'] : null;
$data = isset($_GET['data']) ? $_GET['data'] : null;
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

try {
    // Construir query
    $query = "SELECT * FROM agendamentos WHERE 1=1";
    
    if ($status) {
        $query .= " AND status = :status";
    }
    
    if ($data) {
        $query .= " AND data = :data";
    }
    
    $query .= " ORDER BY data DESC, hora DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    if ($status) {
        $stmt->bindParam(":status", $status);
    }
    
    if ($data) {
        $stmt->bindParam(":data", $data);
    }
    
    $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
    $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    
    $agendamentos = array();
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $agendamentos[] = $row;
    }
    
    // Contar total de registros
    $query_count = "SELECT COUNT(*) as total FROM agendamentos WHERE 1=1";
    if ($status) {
        $query_count .= " AND status = '$status'";
    }
    if ($data) {
        $query_count .= " AND data = '$data'";
    }
    
    $stmt_count = $db->prepare($query_count);
    $stmt_count->execute();
    $total = $stmt_count->fetch(PDO::FETCH_ASSOC)['total'];
    
    http_response_code(200);
    echo json_encode(array(
        "success" => true,
        "total" => intval($total),
        "count" => count($agendamentos),
        "data" => $agendamentos
    ));
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro: " . $e->getMessage()
    ));
}
?>
