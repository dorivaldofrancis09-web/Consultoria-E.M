<?php
/**
 * API: Atualizar Status do Agendamento
 * EMM Consultoria
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, PUT");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once '../config/database.php';

// Receber dados JSON
$data = json_decode(file_get_contents("php://input"));

// Validar dados
if (empty($data->id) || empty($data->status)) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "ID e status são obrigatórios."
    ));
    exit();
}

// Validar status
$status_validos = ['pendente', 'confirmado', 'cancelado', 'concluido'];
if (!in_array($data->status, $status_validos)) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Status inválido. Use: pendente, confirmado, cancelado ou concluido."
    ));
    exit();
}

// Conectar ao banco
$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro ao conectar com o banco de dados."
    ));
    exit();
}

try {
    // Verificar se agendamento existe
    $query_check = "SELECT * FROM agendamentos WHERE id = :id";
    $stmt_check = $db->prepare($query_check);
    $stmt_check->bindParam(":id", $data->id);
    $stmt_check->execute();

    if ($stmt_check->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(array(
            "success" => false,
            "message" => "Agendamento não encontrado."
        ));
        exit();
    }

    $agendamento = $stmt_check->fetch(PDO::FETCH_ASSOC);

    // Atualizar status
    $query = "UPDATE agendamentos SET status = :status WHERE id = :id";
    $stmt = $db->prepare($query);
    
    $stmt->bindParam(":status", $data->status);
    $stmt->bindParam(":id", $data->id);
    
    if ($stmt->execute()) {
        // Enviar notificação se foi confirmado
        if ($data->status === 'confirmado') {
            enviarNotificacaoConfirmacao($agendamento);
        }

        http_response_code(200);
        echo json_encode(array(
            "success" => true,
            "message" => "Status atualizado com sucesso!",
            "data" => array(
                "id" => $data->id,
                "status" => $data->status
            )
        ));
    } else {
        http_response_code(500);
        echo json_encode(array(
            "success" => false,
            "message" => "Não foi possível atualizar o status."
        ));
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro: " . $e->getMessage()
    ));
}

/**
 * Enviar notificação de confirmação
 */
function enviarNotificacaoConfirmacao($agendamento) {
    $para = $agendamento['email'];
    $assunto = "Agendamento Confirmado - EMM Consultoria";
    
    $mensagem = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .container { padding: 20px; background-color: #f4f4f4; }
            .content { background-color: white; padding: 20px; border-radius: 10px; }
            .header { color: #1a4d2e; font-size: 24px; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='content'>
                <h2 class='header'>✓ Agendamento Confirmado!</h2>
                <p>Olá {$agendamento['nome']},</p>
                <p>O seu agendamento foi oficialmente <strong>confirmado</strong>!</p>
                <div style='margin: 20px 0; padding: 15px; background: #d4edda; border-radius: 5px;'>
                    <strong>Serviço:</strong> {$agendamento['servico']}<br>
                    <strong>Data:</strong> {$agendamento['data']}<br>
                    <strong>Hora:</strong> {$agendamento['hora']}
                </div>
                <p>Aguardamos por si!</p>
                <p style='margin-top: 30px; color: #666;'>
                    <strong>E.M.M Consultoria</strong><br>
                    Email: geralemmconsultoria@gmail.com<br>
                    Telefone: +244 934 860 617
                </p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@emmconsultoria.ao" . "\r\n";
    
    mail($para, $assunto, $mensagem, $headers);
}
?>
