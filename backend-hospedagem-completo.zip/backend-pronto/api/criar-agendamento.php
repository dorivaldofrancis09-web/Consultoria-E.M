<?php
/**
 * API: Criar Agendamento
 * EMM Consultoria
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once '../config/database.php';

// Receber dados JSON
$data = json_decode(file_get_contents("php://input"));

// Validar dados recebidos
if (
    empty($data->nome) ||
    empty($data->email) ||
    empty($data->telefone) ||
    empty($data->servico) ||
    empty($data->data) ||
    empty($data->hora)
) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Dados incompletos. Preencha todos os campos obrigatórios."
    ));
    exit();
}

// Validar horário de funcionamento
$hora = $data->hora;
list($hours, $minutes) = explode(':', $hora);
$hours = intval($hours);

if ($hours < 8 || $hours >= 19) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Estamos fechados nesse horário. Por favor, agende entre 08:00 e 19:00."
    ));
    exit();
}

// Validar data (não pode ser no passado)
$dataAgendamento = new DateTime($data->data);
$hoje = new DateTime();
$hoje->setTime(0, 0, 0);

if ($dataAgendamento < $hoje) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Não é possível agendar para uma data passada."
    ));
    exit();
}

// Validar email
if (!filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(array(
        "success" => false,
        "message" => "Email inválido."
    ));
    exit();
}

// Conectar ao banco
$database = new Database();
$db = $database->getConnection();

if ($db === null) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro ao conectar com o banco de dados."
    ));
    exit();
}

try {
    // Verificar se já existe agendamento para mesma data/hora
    $query_check = "SELECT id FROM agendamentos WHERE data = :data AND hora = :hora AND status != 'cancelado'";
    $stmt_check = $db->prepare($query_check);
    $stmt_check->bindParam(":data", $data->data);
    $stmt_check->bindParam(":hora", $data->hora);
    $stmt_check->execute();

    if ($stmt_check->rowCount() > 0) {
        http_response_code(409);
        echo json_encode(array(
            "success" => false,
            "message" => "Já existe um agendamento para este horário. Por favor, escolha outro."
        ));
        exit();
    }

    // Inserir agendamento
    $query = "INSERT INTO agendamentos (nome, email, telefone, servico, data, hora, mensagem, status) 
              VALUES (:nome, :email, :telefone, :servico, :data, :hora, :mensagem, 'pendente')";
    
    $stmt = $db->prepare($query);
    
    $stmt->bindParam(":nome", $data->nome);
    $stmt->bindParam(":email", $data->email);
    $stmt->bindParam(":telefone", $data->telefone);
    $stmt->bindParam(":servico", $data->servico);
    $stmt->bindParam(":data", $data->data);
    $stmt->bindParam(":hora", $data->hora);
    
    $mensagem = isset($data->mensagem) ? $data->mensagem : "";
    $stmt->bindParam(":mensagem", $mensagem);
    
    if ($stmt->execute()) {
        $agendamento_id = $db->lastInsertId();
        
        // Enviar notificações
        enviarNotificacoes($data, $agendamento_id);
        
        http_response_code(201);
        echo json_encode(array(
            "success" => true,
            "message" => "Agendamento criado com sucesso!",
            "data" => array(
                "id" => $agendamento_id,
                "nome" => $data->nome,
                "data" => $data->data,
                "hora" => $data->hora,
                "servico" => $data->servico
            )
        ));
    } else {
        http_response_code(500);
        echo json_encode(array(
            "success" => false,
            "message" => "Não foi possível criar o agendamento."
        ));
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        "success" => false,
        "message" => "Erro: " . $e->getMessage()
    ));
}

/**
 * Função para enviar notificações
 */
function enviarNotificacoes($data, $agendamento_id) {
    // Enviar email para o proprietário
    enviarEmailProprietario($data, $agendamento_id);
    
    // Enviar email de confirmação para o cliente
    enviarEmailCliente($data);
    
    // Simular envio de SMS (você precisará integrar com um serviço de SMS real)
    // enviarSMS($data);
}

/**
 * Enviar email para o proprietário
 */
function enviarEmailProprietario($data, $id) {
    $para = "geralemmconsultoria@gmail.com";
    $assunto = "Novo Agendamento - EMM Consultoria";
    
    $mensagem = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .container { padding: 20px; background-color: #f4f4f4; }
            .content { background-color: white; padding: 20px; border-radius: 10px; }
            .header { color: #1a4d2e; font-size: 24px; margin-bottom: 20px; }
            .info { margin: 10px 0; }
            .label { font-weight: bold; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='content'>
                <h2 class='header'>Novo Agendamento Recebido!</h2>
                <div class='info'><span class='label'>ID:</span> #$id</div>
                <div class='info'><span class='label'>Nome:</span> {$data->nome}</div>
                <div class='info'><span class='label'>Email:</span> {$data->email}</div>
                <div class='info'><span class='label'>Telefone:</span> {$data->telefone}</div>
                <div class='info'><span class='label'>Serviço:</span> {$data->servico}</div>
                <div class='info'><span class='label'>Data:</span> {$data->data}</div>
                <div class='info'><span class='label'>Hora:</span> {$data->hora}</div>
                " . (isset($data->mensagem) && !empty($data->mensagem) ? "<div class='info'><span class='label'>Mensagem:</span> {$data->mensagem}</div>" : "") . "
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@emmconsultoria.ao" . "\r\n";
    
    mail($para, $assunto, $mensagem, $headers);
}

/**
 * Enviar email de confirmação para o cliente
 */
function enviarEmailCliente($data) {
    $para = $data->email;
    $assunto = "Confirmação de Agendamento - EMM Consultoria";
    
    $mensagem = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; }
            .container { padding: 20px; background-color: #f4f4f4; }
            .content { background-color: white; padding: 20px; border-radius: 10px; }
            .header { color: #1a4d2e; font-size: 24px; margin-bottom: 20px; }
            .info { margin: 10px 0; }
            .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='content'>
                <h2 class='header'>Agendamento Confirmado!</h2>
                <p>Olá {$data->nome},</p>
                <p>O seu agendamento foi confirmado com sucesso!</p>
                <div class='info'><strong>Serviço:</strong> {$data->servico}</div>
                <div class='info'><strong>Data:</strong> {$data->data}</div>
                <div class='info'><strong>Hora:</strong> {$data->hora}</div>
                <p style='margin-top: 20px;'>Entraremos em contacto em breve para confirmar todos os detalhes.</p>
                <div class='footer'>
                    <p><strong>E.M.M Consultoria</strong></p>
                    <p>Email: geralemmconsultoria@gmail.com</p>
                    <p>Telefone: +244 934 860 617</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@emmconsultoria.ao" . "\r\n";
    
    mail($para, $assunto, $mensagem, $headers);
}
?>
