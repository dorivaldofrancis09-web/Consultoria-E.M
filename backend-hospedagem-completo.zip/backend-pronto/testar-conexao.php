<?php
/**
 * Script de Teste de Conexão com o Banco de Dados
 * Execute este arquivo para verificar se a conexão está funcionando
 * 
 * IMPORTANTE: Após testar, DELETE este arquivo por segurança!
 */

header('Content-Type: application/json; charset=utf-8');

// Incluir arquivo de configuração
require_once 'config/database.php';

// Criar instância do banco
$database = new Database();

// Testar conexão
$resultado = $database->testarConexao();

// Exibir resultado
echo json_encode($resultado, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Se a conexão foi bem sucedida, testar se a tabela existe
if ($resultado['success']) {
    try {
        $conn = $database->getConnection();
        $query = "SHOW TABLES";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $tabelas = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "\n\n=== TABELAS ENCONTRADAS ===\n";
        echo json_encode($tabelas, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        
        if (empty($tabelas)) {
            echo "\n\n⚠️ ATENÇÃO: Nenhuma tabela encontrada!";
            echo "\nImporte o arquivo database/schema.sql";
        }
    } catch(PDOException $e) {
        echo "\n\nErro ao verificar tabelas: " . $e->getMessage();
    }
}

echo "\n\n✅ Teste concluído!";
echo "\n⚠️ LEMBRE-SE: Delete este arquivo (testar-conexao.php) após o teste!";
?>
